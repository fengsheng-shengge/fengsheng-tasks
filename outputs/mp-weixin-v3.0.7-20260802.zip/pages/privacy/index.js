"use strict";const e={data:()=>({})};const r=require("../../common/vendor.js")._export_sfc(e,[["render",function(e,r,t,c,n,o){return{}}],["__scopeId","data-v-5abef09b"]]);wx.createPage(r);
