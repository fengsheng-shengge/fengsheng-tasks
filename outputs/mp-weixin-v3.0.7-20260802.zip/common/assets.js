"use strict";exports.hero1="/static/hero1.png",exports.hero2="/static/hero2.png",exports.hero3="/static/hero3.png",exports.hero4="/static/hero4.png";
