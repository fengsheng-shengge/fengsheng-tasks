#!/bin/bash
# ============================================================
# 沃土计划 Flask v1.9.1+ 补丁一键部署
# 用法：在 wotu_web 目录内执行：bash apply_patch.sh
# 做什么：覆盖 app.py、加 register.html/landing.html、写 gongan_no、重启
# ============================================================
set -e

HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE"

echo "▶ 1/5 备份"
TS=$(date +%m%d%H%M)
cp app.py app.py.bak.$TS
cp wotu_full.db wotu_full.db.bak.$TS
echo "✅ 已备份 app.py / wotu_full.db 到 .bak.$TS"

echo "▶ 2/5 覆盖 app.py（含 /register + / landing 路由）"
# 补丁文件在脚本同目录
if [ -f "app.py.new" ]; then
  cp app.py.new app.py
  echo "✅ 已用 app.py.new 覆盖"
else
  echo "ℹ 没找到 app.py.new，跳过（你可能已经手动改过）"
fi

echo "▶ 3/5 加两个新模板"
cp register.html templates/ 2>/dev/null || echo "ℹ register.html 不在根目录，跳过"
cp landing.html  templates/ 2>/dev/null || echo "ℹ landing.html 不在根目录，跳过"
ls -la templates/register.html templates/landing.html 2>/dev/null && echo "✅ 两个模板就位"

echo "▶ 4/5 写 gongan_no 到 DB"
sqlite3 wotu_full.db "INSERT OR REPLACE INTO system_config (key, value) VALUES ('gongan_no', '京公网安备11010802051263号');"
echo "✅ gongan_no 已写入"
sqlite3 wotu_full.db "SELECT key, value FROM system_config WHERE key='gongan_no';"

echo "▶ 5/5 重启 Flask"
# systemd
if systemctl is-active --quiet wotu 2>/dev/null; then
  systemctl restart wotu && echo "✅ systemd wotu 已重启"
# supervisor
elif supervisorctl status wotu 2>/dev/null | grep -q RUNNING; then
  supervisorctl restart wotu && echo "✅ supervisor wotu 已重启"
# cloudflared tunnel + gunicorn 手动
else
  pkill -f "gunicorn.*app:app" 2>/dev/null || true
  sleep 1
  setsid ./venv/bin/gunicorn -w 2 -b 127.0.0.1:5001 --timeout 60 \
    --access-logfile /tmp/wotu_access.log --error-logfile /tmp/wotu_error.log \
    app:app > /dev/null 2>&1 < /dev/null &
  sleep 3
  curl -s http://127.0.0.1:5001/healthz && echo " ✅ Flask 已重启"
fi

echo ""
echo "------------------------------------------------------------"
echo "  🎉 部署完成！验证 3 条"
echo "  curl -s http://127.0.0.1:5001/register    → 200"
echo "  curl -s http://127.0.0.1:5001/            → 200 (landing)"
echo "  curl -s http://127.0.0.1:5001/login       → 200"
echo "------------------------------------------------------------"
