#!/bin/bash
# 沃土计划 · 一键更新
# 保存到本地后，每次跑：bash update.sh

echo "=== 停旧服务 ==="
pkill -f "python3 app.py" 2>/dev/null
sleep 1

echo "=== 下载最新代码 ==="
cd ~/Downloads
curl -L -o wotu_latest.zip "https://aka.doubaocdn.com/s/39k1mAddCL"

echo "=== 解压 ==="
rm -rf wotu_web
unzip -o wotu_latest.zip -d wotu_web 2>/dev/null

echo "=== 启动 ==="
cd wotu_web
python3 app.py
