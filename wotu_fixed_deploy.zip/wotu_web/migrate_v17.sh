#!/bin/bash
# ============================================================
# 沃土计划 · v1.7 大迭代迁移脚本（本地库升级）
# 适用：从 v1.6（或更早）升级到 v1.7
# 用法：在 wotu_web 目录下执行  bash migrate_v17.sh
# ============================================================
set -e
DB=wotu_full.db
[ -f "$DB" ] || { echo "❌ 未找到 $DB，请确认在 wotu_web 目录执行"; exit 1; }

echo "▶ 1/4 备份数据库"
cp "$DB" "${DB}.bak_v16" && echo "✅ 已备份 → ${DB}.bak_v16"

python3 << 'PYEOF'
import sqlite3
conn = sqlite3.connect("wotu_full.db")

# 1) cert 多版本治理：每个学员仅保留最新 cert_id 版本（is_valid=1），其余归档
rows = conn.execute("SELECT sid FROM campus_cert_result WHERE is_valid=1 GROUP BY sid HAVING COUNT(*)>1").fetchall()
archived = 0
for (sid,) in rows:
    ids = [r[0] for r in conn.execute(
        "SELECT cert_id FROM campus_cert_result WHERE sid=? AND is_valid=1 ORDER BY cert_id DESC", (sid,)).fetchall()]
    for old in ids[1:]:
        conn.execute("UPDATE campus_cert_result SET is_valid=0 WHERE cert_id=?", (old,))
        archived += 1
print(f"✅ cert 多版本归档 {archived} 条（保留最新）")

# 2) 清理 Day>7 残留提交
d = conn.execute("DELETE FROM practice_submission WHERE day > 7").rowcount
print(f"✅ 清理 Day>7 残留提交 {d} 条")

# 3) alumni_performance 加评价角色列（导师端 师傅/店长/雇主）
cols = [c[1] for c in conn.execute("PRAGMA table_info(alumni_performance)").fetchall()]
if "role_type" not in cols:
    conn.execute("ALTER TABLE alumni_performance ADD COLUMN role_type TEXT")
    print("✅ alumni_performance 加 role_type 列")
else:
    print("⏭ alumni_performance 已有 role_type 列")

# 4) 积分规则配置键（PM 设置页可改，助教结算读取）
for k, v in {"points_submit":"3","points_drill":"5","points_review85":"10","points_review60":"5","points_attendance":"20"}.items():
    conn.execute("INSERT OR IGNORE INTO system_config (key, value) VALUES (?,?)", (k, v))
print("✅ 积分配置键写入 system_config")

# 5) showcase_work 补荣誉墙展示列（学员端作品荣誉墙）
for col, ddl in {"category":"TEXT","recommend_reason":"TEXT","publish":"INTEGER DEFAULT 0","recommended_at":"TEXT"}.items():
    cols = [c[1] for c in conn.execute("PRAGMA table_info(showcase_work)").fetchall()]
    if col not in cols:
        conn.execute(f"ALTER TABLE showcase_work ADD COLUMN {col} {ddl}")
        print(f"✅ showcase_work 加 {col} 列")

conn.commit()
print("=== v1.7 迁移完成 ===")
PYEOF

echo "▶ 2/4 校验 app.py 语法"
python3 -c "compile(open('app.py').read(),'app.py','exec')" && echo "✅ app.py OK"

echo "▶ 3/4 校验服务启动"
fuser -k 5001/tcp 2>/dev/null || true
nohup python3 app.py > /tmp/wotu_v17.log 2>&1 &
sleep 3
curl -s http://127.0.0.1:5001/healthz && echo " ✅ 服务正常"

echo "▶ 4/4 完成"
echo "👉 本地启动：cd wotu_web && python3 app.py（端口 5001）"
echo "👉 服务器部署：将 app.py / templates/ / static/ 上传至 /root/wotu_app 并 systemctl restart wotu"
