#!/bin/bash
# ============================================================
# 沃土计划 · v1.8 迁移脚本（本地库升级，兼容 v1.4~v1.7 任意旧库）
# 新增：①成绩申诉闭环 ②学习行为记录 ③演示模式开关 ④v1.7 全部变更(幂等)
# 用法：在 wotu_web 目录执行  bash migrate_v18.sh
# ============================================================
set -e
DB=wotu_full.db
[ -f "$DB" ] || { echo "❌ 未找到 $DB"; exit 1; }

echo "▶ 1/4 备份数据库"
cp "$DB" "${DB}.bak_v17" && echo "✅ 已备份 → ${DB}.bak_v17"

python3 << 'PYEOF'
import sqlite3
conn = sqlite3.connect("wotu_full.db")

def cols(t):
    return [c[1] for c in conn.execute(f"PRAGMA table_info({t})").fetchall()]

# 1) cert 多版本治理（幂等）
archived = 0
for (sid,) in conn.execute("SELECT sid FROM campus_cert_result WHERE is_valid=1 GROUP BY sid HAVING COUNT(*)>1").fetchall():
    ids = [r[0] for r in conn.execute(
        "SELECT cert_id FROM campus_cert_result WHERE sid=? AND is_valid=1 ORDER BY cert_id DESC", (sid,)).fetchall()]
    for old in ids[1:]:
        conn.execute("UPDATE campus_cert_result SET is_valid=0 WHERE cert_id=?", (old,))
        archived += 1
print(f"✅ cert 多版本归档 {archived} 条")

# 2) Day>7 残留清理
print(f"✅ 清理 Day>7 提交 {conn.execute('DELETE FROM practice_submission WHERE day>7').rowcount} 条")

# 3) alumni_performance.role_type
if "role_type" not in cols("alumni_performance"):
    conn.execute("ALTER TABLE alumni_performance ADD COLUMN role_type TEXT"); print("✅ alumni_performance.role_type")
else:
    print("⏭ alumni_performance.role_type 已存在")

# 4) showcase_work 荣誉墙展示列
for col, ddl in {"category":"TEXT","recommend_reason":"TEXT","publish":"INTEGER DEFAULT 0","recommended_at":"TEXT"}.items():
    if col not in cols("showcase_work"):
        conn.execute(f"ALTER TABLE showcase_work ADD COLUMN {col} {ddl}"); print(f"✅ showcase_work.{col}")
    else:
        print(f"⏭ showcase_work.{col} 已存在")

# 5) 积分配置键 + 演示模式键
for k, v in {"points_submit":"3","points_drill":"5","points_review85":"10","points_review60":"5","points_attendance":"20","demo_mode":"1"}.items():
    conn.execute("INSERT OR IGNORE INTO system_config (key, value) VALUES (?,?)", (k, v))
print("✅ system_config 配置键（积分+演示模式）")

# 6) study_activity 学习行为表（v1.8）
conn.execute("""CREATE TABLE IF NOT EXISTS study_activity (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  sid TEXT, act_type TEXT, detail TEXT, created_at TEXT)""")
print("✅ study_activity 表（v1.8 学习打卡）")

conn.commit()
print("=== v1.8 迁移完成 ===")
PYEOF

echo "▶ 2/4 校验 app.py"
python3 -c "compile(open('app.py').read(),'app.py','exec')" && echo "✅ app.py OK"

echo "▶ 3/4 校验服务"
fuser -k 5001/tcp 2>/dev/null || true
nohup python3 app.py > /tmp/wotu_v18.log 2>&1 &
sleep 3
curl -s http://127.0.0.1:5001/healthz && echo " ✅ 服务正常"

echo "▶ 4/4 完成"
echo "👉 本地：cd wotu_web && python3 app.py（端口 5001）"
echo "👉 服务器：上传 app.py/templates/static 至 /root/wotu_app 后 systemctl restart wotu"
