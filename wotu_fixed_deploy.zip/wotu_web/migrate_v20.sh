#!/bin/bash
# ============================================================
# 沃土计划 · v2.0 库结构对齐脚本（幂等，可重复执行）
# 本次变更：
#   1) alumni_performance 补 role_type 列（师傅/店长/雇主评价角色）
#   2) system_config 补 gongan_no 键（公安联网备案号，留空则页脚不展示）
# 用法：在 wotu_web 目录执行  bash migrate_v20.sh
# 说明：全新交付包内的 wotu_full.db 已包含以上变更，本脚本用于已有库升级
# ============================================================
set -e
DB=wotu_full.db
[ -f "$DB" ] || { echo "❌ 未找到 $DB"; exit 1; }

echo "▶ 1/3 备份数据库"
cp "$DB" "${DB}.bak_v20" && echo "✅ 已备份 → ${DB}.bak_v20"

python3 << 'PYEOF'
import sqlite3
conn = sqlite3.connect("wotu_full.db")

cols = [r[1] for r in conn.execute("PRAGMA table_info(alumni_performance)").fetchall()]
if "role_type" in cols:
    print("⏭ alumni_performance.role_type 已存在")
else:
    conn.execute("ALTER TABLE alumni_performance ADD COLUMN role_type TEXT")
    print("✅ alumni_performance 已补 role_type 列")

row = conn.execute("SELECT value FROM system_config WHERE key='gongan_no'").fetchone()
if row:
    print("⏭ system_config.gongan_no 已存在：", row[0] or "（空）")
else:
    conn.execute("INSERT INTO system_config (key, value) VALUES ('gongan_no', '')")
    print("✅ system_config 已补 gongan_no 键（PM 后台填写后页脚展示）")

conn.commit()
conn.execute("PRAGMA journal_mode=WAL")
print("✅ 库已切换 WAL 模式（多 worker 并发更稳）")
conn.close()
PYEOF

echo "▶ 2/3 校验 app.py"
python3 -c "compile(open('app.py').read(),'app.py','exec')" && echo "✅ app.py OK"

echo "▶ 3/3 完成"
echo "重启服务后生效：systemctl restart wotu   或   bash update.sh"
