#!/bin/bash
# ============================================================
# 沃土计划 · v1.9 迁移脚本（本地库升级，兼容 v1.4~v1.8）
# 本次变更：备案号写入 + 预备经纪人定位文案（无新表）
# 用法：在 wotu_web 目录执行  bash migrate_v19.sh
# ============================================================
set -e
DB=wotu_full.db
[ -f "$DB" ] || { echo "❌ 未找到 $DB"; exit 1; }

echo "▶ 1/3 备份数据库"
cp "$DB" "${DB}.bak_v18" && echo "✅ 已备份 → ${DB}.bak_v18"

python3 << 'PYEOF'
import sqlite3
conn = sqlite3.connect("wotu_full.db")
# 写入 ICP 备案号（若老库为空）
conn.execute("INSERT OR REPLACE INTO system_config (key, value) VALUES ('icp_no', '京ICP备2026044043号')")
conn.commit()
print("✅ 备案号:", conn.execute("SELECT value FROM system_config WHERE key='icp_no'").fetchone()[0])
print("✅ v1.9 配置完成")
PYEOF

echo "▶ 2/3 校验 app.py"
python3 -c "compile(open('app.py').read(),'app.py','exec')" && echo "✅ app.py OK"

echo "▶ 3/3 重启服务"
fuser -k 5001/tcp 2>/dev/null || true
nohup python3 app.py > /tmp/wotu_v19.log 2>&1 &
sleep 3
curl -s http://127.0.0.1:5001/healthz && echo " ✅ 服务正常"
