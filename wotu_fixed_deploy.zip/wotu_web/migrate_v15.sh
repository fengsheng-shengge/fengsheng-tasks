#!/bin/bash
# 沃土 v1.6 迁移：助教带练督导 3 张新表（幂等）
DB=wotu_full.db
sqlite3 "$DB" <<SQL
CREATE TABLE IF NOT EXISTS points_record (id INTEGER PRIMARY KEY AUTOINCREMENT, sid TEXT NOT NULL, day_no INTEGER DEFAULT 0, action_type TEXT, points INTEGER, reason TEXT, created_by TEXT, created_at TEXT);
CREATE TABLE IF NOT EXISTS supervision_log (id INTEGER PRIMARY KEY AUTOINCREMENT, sid TEXT NOT NULL, day_no INTEGER, content TEXT, status TEXT DEFAULT 'pending', created_by TEXT, created_at TEXT);
CREATE TABLE IF NOT EXISTS excellent_nomination (id INTEGER PRIMARY KEY AUTOINCREMENT, sid TEXT NOT NULL, round_name TEXT, reason TEXT, points_total INTEGER DEFAULT 0, task_done INTEGER DEFAULT 0, avg_score REAL DEFAULT 0, status TEXT DEFAULT 'nominated', created_by TEXT, created_at TEXT, UNIQUE(sid, round_name));
SQL
echo "=== 表核对 ==="
for T in points_record supervision_log excellent_nomination alumni alumni_performance mentor_profile showcase_work; do
  echo "$T: $(sqlite3 "$DB" "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='$T';")"
done
