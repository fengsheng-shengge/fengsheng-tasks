#!/bin/bash
# ============================================================
# 沃土计划 · 服务器首次部署 / 重新部署（Ubuntu 20.04+）
# 用法：把整个 wotu_web 目录上传到服务器后，在目录内执行
#   bash deploy_server.sh            # 安装依赖 + 库结构对齐 + 启动并自检
# 说明：脚本不修改系统级配置；systemd 常驻请按输出提示手动创建
# ============================================================
set -e
cd "$(dirname "$0")"

echo "▶ 1/5 环境检查"
python3 -V || { echo "❌ 未安装 python3"; exit 1; }
python3 -c "import venv" 2>/dev/null || { echo "❌ 缺少 venv，请先执行 apt install -y python3-venv"; exit 1; }

echo "▶ 2/5 创建虚拟环境并安装依赖"
[ -d venv ] || python3 -m venv venv
./venv/bin/pip install --upgrade pip -q
./venv/bin/pip install -r requirements.txt -q
echo "✅ 依赖已就绪"

echo "▶ 3/5 库结构对齐（幂等）"
if [ -f wotu_full.db ]; then
  bash migrate_v20.sh || { echo "❌ 迁移失败，请检查上面的报错"; exit 1; }
else
  echo "❌ 未找到 wotu_full.db，请把数据库一并上传"
  exit 1
fi

echo "▶ 4/5 目录与权限"
mkdir -p uploads
chmod 755 uploads
ls -1 .secret_key >/dev/null 2>&1 || echo "ℹ 首次启动会自动生成 .secret_key（会话密钥）"

echo "▶ 5/5 启动并自检"
pkill -f "gunicorn.*app:app" 2>/dev/null || true
sleep 1
setsid ./venv/bin/gunicorn -w 2 -b 127.0.0.1:5001 --timeout 60 \
  --access-logfile /tmp/wotu_access.log --error-logfile /tmp/wotu_error.log \
  app:app > /dev/null 2>&1 < /dev/null &
sleep 4
curl -s http://127.0.0.1:5001/healthz && echo " ✅ 服务已启动"

cat <<'EOF'

------------------------------------------------------------
常驻服务（systemd）：新建 /etc/systemd/system/wotu.service

[Unit]
Description=Wotu Plan
After=network.target

[Service]
User=root
WorkingDirectory=/root/wotu_app
ExecStart=/root/wotu_app/venv/bin/gunicorn -w 2 -b 127.0.0.1:5001 --timeout 60 app:app
Restart=always

[Install]
WantedBy=multi-user.target

然后执行：
  systemctl daemon-reload && systemctl enable --now wotu
  systemctl status wotu
------------------------------------------------------------
EOF
